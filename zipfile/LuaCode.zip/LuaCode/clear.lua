
function clear()
    for k,v in pairs(package.loaded) do
        print("loaded key:" .. k);
    end

    package.loaded["clear"] = nil;
    package.loaded["main"] = nil;
    package.loaded["bootstrap"] = nil;
    package.loaded["entry"] = nil;
end


