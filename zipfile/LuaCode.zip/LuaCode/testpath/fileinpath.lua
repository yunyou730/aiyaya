

print("This is fileinpath.lua 中文测试");
for i = 1,5 do
    print("str:" .. i);
end
